grep_cmdline() {
  local REGEX="s/^$1=//p"
  { echo $(cat /proc/cmdline)$(sed -e 's/[^"]//g' -e 's/""//g' /proc/cmdline) | xargs -n 1; \
    sed -e 's/ = /=/g' -e 's/, /,/g' -e 's/"//g' /proc/bootconfig; \
  } 2>/dev/null | sed -n "$REGEX"
}
printMd5() {
  echo "`md5sum $1/boot1.img|cut -d" " -f1` boot.img"
  echo `md5sum /dev/block/sdc32`
  echo `md5sum /dev/block/sdc56`
}
#通过当前的slot决定要更改的分区
SLOT=`grep_cmdline androidboot.slot_suffix`
if [ -z $SLOT ]; then
  SLOT=`grep_cmdline androidboot.slot`
  [ -z $SLOT ] || SLOT=_${SLOT}
fi
[ -z $SLOT ] || echo "- Current boot slot: $SLOT"
case $SLOT in
    _a) bootImage=sdc32;;
    _b) bootImage=sdc56;;
esac
#获取dev里面的sha1值
echo "- get magisk variable"
source "`find /dev -name ".magisk" -type d | head -n 1`/config" 
#如果通过sha1值确定的目录找不到文件，则获取最新的目录
dir="/data/magisk_backup_${SHA1}"
if [[ -d /data/magisk_backup_$SHA1 ]] && [[ -f /data/magisk_backup_$SHA1/boot.img.gz ]]; then
  dir=/data/magisk_backup_$SHA1
  echo "located to ${dir} via SHA1"
else
  dir="/data/`ls -t /data |grep ^magisk | head -n 1`"
  echo "- located to the latest magisk dir ${dir}"
fi
#开始恢复原厂镜像
if [ -f $dir/boot.img.gz ]; then
  echo "- find boot.img.gz"
  echo "- unzip boot.img.gz"
  cp $dir/boot.img.gz $dir/boot1.img.gz
  gzip -d $dir/boot1.img.gz
  echo "- calculate md5"
  printMd5 $dir
  echo "- rm ${bootImage}"
  rm /dev/block/$bootImage
  echo "restore offical boot.img\n\n"
  dd if=$dir/boot1.img of=/dev/block/$bootImage
  echo "\n\n- recalculate md5"
  printMd5 $dir
  echo '- delete temp files'
  rm $dir/boot1.img
  rm $dir/boot1.img.gz
  echo "- DONE"
else
  echo '- not find boot.img.gz, exit'
fi
