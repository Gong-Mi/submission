rm -rf /data/adb/modules_update/K40G-OTAFix
rm -rf /data/adb/modules/K40G-OTAFix