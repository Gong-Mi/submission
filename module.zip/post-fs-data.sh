MODDIR=${0%/*}
